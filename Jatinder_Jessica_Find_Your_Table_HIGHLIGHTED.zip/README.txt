JATINDER & JESSICA — FIND YOUR TABLE WEBSITE

Files included:
- index.html
- style.css
- script.js
- guests.json (254 guest entries across 23 tables)
- logo.svg
- venue-layout.svg (temporary placeholder)

TO ADD YOUR FINAL VENUE LAYOUT
1. Put your final venue layout image in this folder.
2. Name it exactly:
   venue-layout.png
   OR venue-layout.jpg
3. You can leave venue-layout.svg in place as a fallback.

TO PUBLISH ON GITHUB PAGES
1. Create a new public GitHub repository.
2. Upload every file from this folder to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select main and /(root), then Save.
6. GitHub will provide a public link.
7. In Google Sites: Insert > Embed > By URL, then paste that link.

PRIVACY NOTE
The guest names and table assignments are stored in guests.json and are therefore technically visible
to anyone who inspects the public website files.

NEW: The selected guest's table is automatically highlighted and centred on the venue layout.
